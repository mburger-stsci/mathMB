.. _atomicmass_:

**********
atomicmass
**********

.. moduleauthor:: Matthew Burger <mburger@stsci.edu>

.. automodule:: physicsMB.atomicmass
  :members: atomicmass
