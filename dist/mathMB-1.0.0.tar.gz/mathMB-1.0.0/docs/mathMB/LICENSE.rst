*******
LICENSE
*******

.. include:: ../../licenses/LICENSE.rst 
